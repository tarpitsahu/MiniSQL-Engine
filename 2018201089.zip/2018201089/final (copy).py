import sqlparse
import itertools
import sys
def max(A):
	global result_rows
	maxi=-99999
	for i in result_rows:
		if(i[A]>maxi):
			maxi=i[A]
	return maxi

def sum(A):
	global result_rows
	sumi=0
	for i in result_rows:
		sumi+=i[A]
	
	return sumi

def avg(A):
	global result_rows
	
	return float(sum(A))/len(result_rows)

def min(A):
	global result_rows
	mini=999999
	for i in result_rows:
		if(i[A]<mini):
			mini=i[A]
	return mini


	



def read_metadata():
	f=open('metadata.txt','r')
	lines=f.readlines()
	for i in lines:
		if('<begin_table>' in i):
			lines.remove(i)
	metadata={}
	start=0
	for i in lines:
		i=i.rstrip('\r\n')
		if(start==0):
			table_name=i
			metadata[table_name]=[]
			start=1
			continue	
		elif('<end_table>' in i):
			start=0		
		elif(start):
			metadata[table_name].append(i)
	return metadata

def read_tables(metadata):
	database={}
	for i in metadata:
		f=open(i+'.csv','r')
		data=f.readlines()
		database[i]=data
	
	return database

def clean_database(database):
	for i in database:
		for j in range(len(database[i])):
			database[i][j]=database[i][j].rstrip('\r\n')
			database[i][j]=database[i][j].split(',')
			
			for k in range(len(database[i][j])):
				database[i][j][k]=int(database[i][j][k])
	
	return database
def generate_query_tree(query):
	query_tree={}
	query_tree['where']="-"
	query_tree['from']="-"
	query_tree['select']="-"
	
	
	try:
		temp=query.split(' where ')[1]
		#print temp
		query_tree['where']=" "+temp;
		query=query.split(' where ')
		query=query[:-1]
		query=str(query[0])
	except:
		pass
	
	try:
		temp=query.split(' from ')[1]
		#print temp
		query_tree['from']=temp.split(',');
		query=query.split(' from ')
		query=query[:-1]
		query=str(query[0])
	except:
		pass

	try:
		temp=query.split('select ')[1]
		#print temp
		query_tree['select']=temp.split(',');
		query=query.split('select ')
		query=query[:-1]
		query=str(query[0])
	except:
		pass
	
	
	
	
	return query_tree

def preprocess_query(query):
	query=sqlparse.format(query,keyword_case='lower')
	query=str(query)
	query=query.replace(' , ',',')
	query=query.replace(', ',',')
	query=query.replace(' ,',',')

	query=query.replace(' = ','==')
	query=query.replace('= ','==')
	query=query.replace(' =','==')
	
	
	

	query=query.replace(' <= ','<=')
	query=query.replace('<= ','<=')
	query=query.replace(' <=','<=')

	query=query.replace(' >= ','>=')
	query=query.replace('>= ','>=')
	query=query.replace(' >=','>=')

	query=query.replace(' < ','<')
	query=query.replace('< ','<')
	query=query.replace(' <','<')

	query=query.replace(' > ','>')
	query=query.replace('> ','>')
	query=query.replace(' >','>')







	return query




if __name__ == '__main__':
	try:
		metadata=read_metadata()
		database=read_tables(metadata)
		database=clean_database(database)
		#print database
		distinct=0
	
	
		#query="Select * from table1,table2 where table1.B=table2.B and table2.D>20"#where a=1 AND p=2;";
		query=sys.argv[1]
		#print query
		query=query.strip(' ')
		if(query[-1]!=';'):
			print "Error:Semicolon Missing"
			exit()
		
		query=query.strip(';')
		query=query.strip(' ')
		
		query=preprocess_query(query)
		
		if('select distinct ' in query):
			distinct=1
			query=query.replace('select distinct','select')
		
		query_tree=generate_query_tree(query)
		#print query_tree
		
		tables_data=[]
		for i in query_tree['from']:
			tables_data.append(database[i])
			
		column_headers_type1=[]
		column_headers_type2=[]
		
		for i in query_tree['from']:
			for j in metadata[i]:
				column_headers_type1.append(j)
				column_headers_type2.append(i+'.'+j)
				
		#print column_headers_type1
		#print column_headers_type2
			
		result_rows=[]	
		for i in itertools.product(*tables_data):
		    li=[]
		    for j in i:
		        li=li+j
		    result_rows.append(li)
		
		for i in column_headers_type1:
			   if("("+i+")" in query_tree['where']):
				          query_tree['where']=query_tree['where'].replace("("+i+")","("+str(column_headers_type1.index(i))+")") 
			   if(" "+i+"=" in query_tree['where']):
				          query_tree['where']=query_tree['where'].replace(" "+i+"="," x["+str(column_headers_type1.index(i))+"]==") 
			   if(" "+i+"<=" in query_tree['where']):
				          query_tree['where']=query_tree['where'].replace(" "+i+"<="," x["+str(column_headers_type1.index(i))+"]<=") 
			   if(" "+i+">=" in query_tree['where']):
				          query_tree['where']=query_tree['where'].replace(" "+i+">="," x["+str(column_headers_type1.index(i))+"]>=") 
			   if(" "+i+"<" in query_tree['where']):
				          query_tree['where']=query_tree['where'].replace(" "+i+"<"," x["+str(column_headers_type1.index(i))+"]<") 
			   if(" "+i+">" in query_tree['where']):
				          query_tree['where']=query_tree['where'].replace(" "+i+">"," x["+str(column_headers_type1.index(i))+"]>") 
		
		
		for i in column_headers_type2:
			if("("+i+")" in query_tree['where']):
				          query_tree['where']=query_tree['where'].replace("("+i+")","("+str(column_headers_type2.index(i))+")") 
			if(" "+i+"=" in query_tree['where']):
				query_tree['where']=query_tree['where'].replace(" "+i+"="," x["+str(column_headers_type2.index(i))+"]==") 
			
			if(" "+i+"<=" in query_tree['where']):
				query_tree['where']=query_tree['where'].replace(" "+i+"<="," x["+str(column_headers_type2.index(i))+"]<=") 
			if(" "+i+">=" in query_tree['where']):
				query_tree['where']=query_tree['where'].replace(" "+i+">="," x["+str(column_headers_type2.index(i))+"]>=") 
			if(" "+i+"<" in query_tree['where']):
				query_tree['where']=query_tree['where'].replace(" "+i+"<"," x["+str(column_headers_type2.index(i))+"]<") 
			if(" "+i+">" in query_tree['where']):
				query_tree['where']=query_tree['where'].replace(" "+i+">"," x["+str(column_headers_type2.index(i))+"]>") 
		
		query_type=1
		try:
			if ("select max(" in query or "select min(" in query or "select sum(" in query or "select avg(" in query):
				query_type=2
			elif('.' in query.split('where')[1].split('=')[0] and '.' in query.split('where')[1].split('=')[1]):
				query_type=3
		except:
			pass
			
				  
		
		if(query_tree['where']!='-' and query_type!=3):
			result_rows=filter(lambda x: eval(query_tree['where']), result_rows)
		
		#print query_type
		
		
		
			
			
		if(query_type==1):
			#print "Type 1 Query"	
			result_columns=[]
			for i in query_tree['select']:
				if('*' in i):
					for j in range(len(column_headers_type1)):
						result_columns.append(j)
					break
				if('.' in i):
					if(column_headers_type2.count(i)>1 or column_headers_type2.count(i)==0 ):
						#print "error"
						break;
					result_columns.append(column_headers_type2.index(i))
				else:
					if(column_headers_type1.count(i)>1 or column_headers_type1.count(i)==0 ):
						#print "error"
						break;
					result_columns.append(column_headers_type1.index(i))
			
			str_row=""
			for j in result_columns:
				str_row=str_row+column_headers_type2[j]+","
			print str_row.strip(',')
			
			final_answer=[]
			for i in result_rows:
				str_row=""
				for j in result_columns:
					str_row=str_row+str(i[j])+','
				final_answer.append(str_row.rstrip(','))
				
			if(distinct==1):
				final_answer=set(final_answer)
				final_answer=list(final_answer)
			
			for i in final_answer:
				print i		
		if(query_type==2):
			cols=[]
			for k in range(len(query_tree['select'])):
				for i in column_headers_type1:
					
					if("("+i+")" in query_tree['select'][k]):
						cols.append(query_tree['select'][k].replace(i,column_headers_type2[column_headers_type1.index(i)]))          
						query_tree['select'][k]=query_tree['select'][k].replace("("+i+")","("+str(column_headers_type1.index(i))+")") 
					  
				for i in column_headers_type2:
					if("("+i+")" in query_tree['select'][k]):
						          cols.append(query_tree['select'][k])
						          query_tree['select'][k]=query_tree['select'][k].replace("("+i+")","("+str(column_headers_type2.index(i))+")") 
					
			#print query_tree	
			#print "Type 2 Query"	
			results=[]
			
			for i in query_tree['select']:
				#print eval(i);
				results.append(eval(i))
			
			str_row=""
			for j in cols:
				str_row=str_row+str(j)+','
			print str_row.rstrip(',')
			
			str_row=""
			for j in results:
				str_row=str_row+str(j)+','
			print str_row.rstrip(',')
		if(query_type==3):
			temp=query.split('where')[1]
			temp=temp.rstrip(';')
			temp=temp.strip(' ')
			
			
			for i in column_headers_type2:
					if(i in temp):
						temp=temp.replace(i,"x["+str(column_headers_type2.index(i))+"]") 
						prev=i
			temp=temp.replace('=','==')
			result_rows=filter(lambda x: eval(temp), result_rows)
			#print "Type 3 Query"	
			result_columns=[]
			for i in query_tree['select']:
				if('*' in i):
					for j in range(len(column_headers_type1)):
						result_columns.append(j)
					break
				if('.' in i):
					if(column_headers_type2.count(i)>1 or column_headers_type2.count(i)==0 ):
						#print "error"
						break;
					result_columns.append(column_headers_type2.index(i))
				else:
					if(column_headers_type1.count(i)>1 or column_headers_type1.count(i)==0 ):
						#print "error"
						break;
					result_columns.append(column_headers_type1.index(i))
			
			result_columns.remove(column_headers_type2.index(prev))
			str_row=""
			for j in result_columns:
				str_row=str_row+column_headers_type2[j]+","
			print str_row.strip(',')
			
			final_answer=[]
			for i in result_rows:
				str_row=""
				for j in result_columns:
					str_row=str_row+str(i[j])+','
				final_answer.append(str_row.rstrip(','))
				
			if(distinct==1):
				final_answer=set(final_answer)
				final_answer=list(final_answer)
			
			for i in final_answer:
				print i
	except:
		print"An Error Occured. Aborting !"
