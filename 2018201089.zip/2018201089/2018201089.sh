python final.py "$@"
